#!/bin/bash

while true; do
	date
	sleep 1
done
